package com.example.moviesong;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private static final String API_KEY = "VOTRE_CLE_API_TMDB"; // Remplacez par votre clé API

    private EditText searchEditText;
    private Button searchButton;
    private RecyclerView recyclerView;
    private TextView resultTextView;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        searchEditText = findViewById(R.id.search_edit_text);
        searchButton = findViewById(R.id.search_button);
        recyclerView = findViewById(R.id.recycler_view);
        resultTextView = findViewById(R.id.result_text_view);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String query = searchEditText.getText().toString();
                fetchMovies(query);
            }
        });
    }

    private void fetchMovies(String query) {
        MovieService movieService = ApiClient.getClient().create(MovieService.class);
        Call<MovieResponse> call = movieService.searchMovies(API_KEY, query);

        call.enqueue(new Callback<MovieResponse>() {
            @Override
            public void onResponse(Call<MovieResponse> call, Response<MovieResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<Movie> movies = response.body().getResults();
                    recyclerView.setAdapter(new MovieAdapter(movies));
                    resultTextView.setVisibility(View.GONE);
                } else {
                    resultTextView.setText("Aucun résultat trouvé.");
                    resultTextView.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onFailure(Call<MovieResponse> call, Throwable t) {
                Log.e("Erreur API", "Échec de la requête", t);
                resultTextView.setText("Erreur lors de la recherche.");
                resultTextView.setVisibility(View.VISIBLE);
            }
        });
    }
}

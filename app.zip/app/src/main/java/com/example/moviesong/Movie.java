package com.example.moviesong;

import java.util.List;

public class Movie {
    private String title;
    private String overview;
    private String poster_path;

    public String getTitle() {
        return title;
    }

    public String getOverview() {
        return overview;
    }

    public String getPosterPath() {
        return poster_path;
    }
}

package com.example.moviesong;

public class Cast {
    private String name;
    private String character;

    public Cast(String name, String character) {
        this.name = name;
        this.character = character;
    }

    public String getName() {
        return name;
    }

    public String getCharacter() {
        return character;
    }
}
